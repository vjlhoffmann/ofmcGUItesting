# Readme for ofmcGUI test users 05.04.2019

Please note that some features are still in development and might have known and unknown errors.

After unzipping make sure to change the following file extension:

run.txt -> run.bat

Please make sure that ofmc.exe is located in the same folder as the ofmcGUI.jar file.
Important : it should be named "ofmc.exe"

The ofmcGUI.jar file is not runnable so it can be launched with the run.bat file.

Before usage the user should install the latest version of Java and Haskell platforms.


If you find any errors or simply have ideas for improvements we kindly ask you to send
us an e-mail to:

s165544@student.dtu.dk
or
s144113@student.dtu.dk


